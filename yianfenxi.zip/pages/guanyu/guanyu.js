Page({
  data:{
    Nav:[
      {
        Navurl:"/pages/guanyu/guiding/guiding",
        Navbutton:"服务协定",
        Navbtn:"wufuxieding"
      },{
        Navurl: "/pages/guanyu/help/help",
        Navbutton: "使用帮助",
        Navbtn:"shiyongbangzhu"
      },{
        Navurl: "/pages/guanyu/feedback/feedback",
        Navbutton: "意见反馈",
        Navbtn:"yijianfankui"
      },{
        Navurl: "/pages/guanyu/update/update",
        Navbutton: "更新检查",
        Navbtn:"gengxinjiancha"
      }
    ]
  }
})